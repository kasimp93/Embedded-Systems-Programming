#!/bin/bash
        
for i in 1 2 3 4 5 6
do
	echo "Welcome to EC535! Welcome to the Spring 2017 Semester!" 
	echo "Current date and time:" $(date)
	sleep 10
done 


